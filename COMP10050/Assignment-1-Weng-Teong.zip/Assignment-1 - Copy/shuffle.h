#include "sort.h"

/*

This function shuffles the array of artists and songs
into a shuffled playlist and outputs it to the console.


*/

void shufflePlaylist(char artists[][MAX_LENGHT], char songs[][MAX_LENGHT], int numOfSongs);